var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://Bence065:asd123@helsinki.cllbxnc.mongodb.net/";

async function egyeniElso() {
  try {
    const client = await MongoClient.connect(url);
    const db = client.db("Helsinki");
    const collection = db.collection("Helsinki");

    const egyeniArany = await collection.find(
      {
        $and: [
          {
            CsapatMeret: { $lt: 2 },
          },
          {
            Helyezes: { $lt: 2 },
          }
        ]
      },
      { projection: { _id: 0, SportAg: 1 } }
    ).toArray();

    console.log(
      "Sportágak melyben egyéni aranyat szereztek a magyarok:",
      egyeniArany
    );

    client.close();
  } catch (err) {
    console.error("Hiba történt az adatok beolvasása közben", err);
  }
}

egyeniElso();
