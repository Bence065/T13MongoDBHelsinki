var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://Bence065:asd123@helsinki.cllbxnc.mongodb.net/";
var helsinkiAdatok = require('./helsinkiAdat');

async function dokumentumFeltoltes(){
    try{
        const client=await MongoClient.connect(url);
        const db=client.db("Helsinki");
        const collection=db.collection("Helsinki");

        const feltoltes=await collection.insertMany(helsinkiAdatok);
        console.log("Dokumentumok feltöltése sikeres:" ,feltoltes.insertedCount, "adat feltöltve");

        client.close();
    }

    catch(err){
        console.error("Sikertelen feltöltés",err)
    }
}

dokumentumFeltoltes();