var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://Bence065:asd123@helsinki.cllbxnc.mongodb.net/";

async function kollekcioLetrehozas() {
  try {
    const client = await MongoClient.connect(url);
    const db = client.db("Helsinki");

    await db.createCollection("Helsinki");
    console.log("Sikeres feltöltés");

    client.close();
  } 
  
  catch (err) {
    console.error("Sikertelen feltöltés", err);
  }
}

kollekcioLetrehozas();
