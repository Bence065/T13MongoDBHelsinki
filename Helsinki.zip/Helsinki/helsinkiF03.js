var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://Bence065:asd123@helsinki.cllbxnc.mongodb.net/";

async function sportagakListazasa() {
  try {
    const client = await MongoClient.connect(url);
    const db = client.db("Helsinki");
    const collection = db.collection("Helsinki");

    const sportag = await collection
      .find(
        {
          $or: [
            {
              SportAg: "uszas",
            },
            {
              SportAg: "torna",
            },
          ],
        },
        { projection: { _id: 0, SportAg: 1, VersenySzam: 1 } }
      )
      .toArray();

    console.log("Versenyszámok torna és úszás sportágban:", sportag);

    client.close();
  } 
  
  catch (err) {
    console.error("Hiba történt az adatok beolvasása közben", err);
  }
}

sportagakListazasa();
