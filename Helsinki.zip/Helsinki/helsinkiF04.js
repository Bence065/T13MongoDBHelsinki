var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://Bence065:asd123@helsinki.cllbxnc.mongodb.net/";

async function dobogosHelyezes() {
  try {
    const client = await MongoClient.connect(url);
    const db = client.db("Helsinki");
    const collection = db.collection("Helsinki");

    const dobogo = await collection
      .find(
        { Helyezes: { $lt: 4 } },
        { projection: { _id: 0, VersenySzam: 1 } }
      )
      .toArray();

    console.log("Versenyszámok amelyben dobogós helyezést értek el a magyarok:", dobogo);

    client.close();
  } catch (err) {
    console.error("Hiba történt az adatok beolvasása közben", err);
  }
}

dobogosHelyezes();