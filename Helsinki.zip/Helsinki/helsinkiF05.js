var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://Bence065:asd123@helsinki.cllbxnc.mongodb.net/";

async function legnagyobbCsapat() {
  try {
    const client = await MongoClient.connect(url);
    const db = client.db("Helsinki");
    const collection = db.collection("Helsinki");

    const rendezes={CsapatMeret:-1}
    const csapatmeret = await collection.find().sort(rendezes).limit(1).toArray();

    console.log("Versenyszámok torna és úszás sportágban:", csapatmeret);

    client.close();
  } 
  
  catch (err) {
    console.error("Hiba történt az adatok beolvasása közben", err);
  }
}

legnagyobbCsapat();
